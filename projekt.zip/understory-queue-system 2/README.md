# Understory Queue System

A simple distributed queue system demo.

sudo systemctl start redis-server

node app.js